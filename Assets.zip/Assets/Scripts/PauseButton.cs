﻿using UnityEngine;
using System.Collections;

public class PauseButton : MonoBehaviour {

	public Sprite[] sprites;
	public SpriteRenderer SR;
	Manager Manager;

	void Start()
	{
		GameObject ManageOJ = GameObject.Find ("Manager");
		Manager = ManageOJ.GetComponent<Manager> ();
	}

	void OnMouseDown()
	{
		if (Manager.paused) {
			Manager.Unpause ();
		} else {
			Manager.Pause();
		}
	}
	// Update is called once per frame
	void Update () {
		if (Manager.paused) {
			SR.sprite = sprites[0];
		} else {
			SR.sprite = sprites[1];
		}
	}
}
