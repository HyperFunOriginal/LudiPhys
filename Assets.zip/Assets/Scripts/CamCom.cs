﻿using UnityEngine;
using System.Collections;

public class CamCom : MonoBehaviour {

	Vector3 DirA;
	Vector3 DirB;
	Vector2 AngleC;
	public float speed;
	// Use this for initialization
	void Start () {
		speed = 0.05f;
		Physics.queriesHitTriggers = false;
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 Angle = transform.eulerAngles * Mathf.Deg2Rad;

		DirA.x = Input.GetAxis ("Horizontal");
		DirA.y = Input.GetAxis ("Forwards") * (-1);
		DirA.z = Input.GetAxis ("Vertical");
		if (Input.GetMouseButton (1)) {
			AngleC.y = Input.GetAxis ("Mouse X");
			AngleC.x = Input.GetAxis ("Mouse Y");
			transform.eulerAngles += new Vector3 (AngleC.x, -AngleC.y, 0) * 5;
		} else if (Input.GetAxis ("LX") != 0 || Input.GetAxis ("LY") != 0) {
			AngleC.y = Input.GetAxis ("LX");
			AngleC.x = Input.GetAxis ("LY");
			transform.eulerAngles += new Vector3 (-AngleC.x, AngleC.y, 0) * 3;
		}

		speed *= (2f + Input.GetAxisRaw ("Mouse ScrollWheel") * 1.5f) * 0.5f;

		DirB.x = (Mathf.Sin (Angle.y) * DirA.z + Mathf.Cos (Angle.y) * DirA.x)* Mathf.Cos(Angle.x);
		DirB.y = Mathf.Sin (Angle.x) * (-1) * DirA.z + Mathf.Cos (Angle.x) * DirA.y;
		DirB.z = (Mathf.Sin (-Angle.y) * DirA.x + Mathf.Cos (-Angle.y) * DirA.z) * Mathf.Cos(Angle.x);

		transform.position += DirB * speed;

		if (Input.GetKeyDown (KeyCode.Slash)) {
			transform.position = Vector3.zero;
		}
	}
}
