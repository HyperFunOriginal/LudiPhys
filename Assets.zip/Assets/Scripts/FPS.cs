﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class FPS : MonoBehaviour {

	int fps;
	GameObject GO;
	Text Txt;
	// Use this for initialization
	void Start () {
		GO = gameObject;
		Txt = GO.GetComponent<Text> ();
		StartCoroutine (second ());
	}
	
	// Update is called once per frame
	void Update () {
		fps++;
	}

	IEnumerator second()
	{
		while (true) {
			Txt.text = Mathf.FloorToInt((10000f / (float) (fps + 0.1f) )* 0.1f).ToString() + " ms";
			if (fps > 40)
			{
				Txt.color = Color.green;
			} else if (fps > 20) {
				Txt.color = Color.yellow;
			} else {
				Txt.color = Color.red;
			}
			fps = 0;
			yield return new WaitForSeconds (1f);
		}
	}
}
