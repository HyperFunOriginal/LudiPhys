﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Accuracy : MonoBehaviour {
	
	GameObject GO;
	Text Txt;
	GameObject Manage;
	Manager Manager;
	// Use this for initialization
	void Start () {
		GO = gameObject;
		Manage = GameObject.Find ("Manager");
		Manager = Manage.GetComponent<Manager> ();
		Txt = GO.GetComponent<Text> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.LeftBracket) && Manager.perfSave > 0f) {
			Manager.perfSave -= 0.002f;
			Manager.perfSave *= 0.99f;
		}
		if (Input.GetKey (KeyCode.RightBracket) && Manager.perfSave < 10f) {
			Manager.perfSave += 0.002f;
			Manager.perfSave *= 1.01f;
		}
		Txt.text = Mathf.CeilToInt(100f / (Manager.perfSave + 1f)).ToString() + " % Acc.";
	}
}
