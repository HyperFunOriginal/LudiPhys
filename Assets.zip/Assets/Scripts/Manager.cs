﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Manager : MonoBehaviour {


	public List<GameObject> GOs = new List<GameObject>();
	public float timestep;
	public bool paused;
	[Range (0f,10f)]
	public float perfSave;

	float cache;

	void Start()
	{
		paused = false;
	}

	void Awake()
	{
		DontDestroyOnLoad(gameObject);
	}

	GameObject[] Array;
	void Update()
	{
		if (!paused) {
			Array = GameObject.FindGameObjectsWithTag ("Particles");
			GOs.Clear ();
			foreach (GameObject GO in Array) {
				GOs.Add (GO);
			}
		}
		if (Input.GetKeyDown (KeyCode.Space) && !paused) {
			Pause ();
		} else if (Input.GetKeyDown (KeyCode.Space) && paused) {
			Unpause();
		}
		if (Input.GetKey (KeyCode.Period)) {
			timestep *= 1.02f;
		} else if (Input.GetKey (KeyCode.Comma)) {
			timestep *= 0.98f;
		} else if (Input.GetKey (KeyCode.RightShift)) {
			timestep = 0.05f;
		}
	}

	public void Unpause()
	{
		paused = false;
		timestep = cache;
		cache = 0f;
	}
	public void Pause()
	{
		paused = true;
		cache = timestep;
		timestep = 0f;
	}
}
