﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

	public class Sphere : MonoBehaviour {

	Vector3 Dir;
	public float MaxDist;
	//initialization
	public Transform transform;
	public float temperature;
	float timestep;
	Vector3 acceleration;
	public Vector3 velocity;
	public List<GameObject> Particles;
	Manager Managers;
	GameObject Manager;
	MeshRenderer meshRenderer;
	public Color basecolor;
	enum State{solid, liquid, gas}
	State state = State.solid;
	float foo;
	
	void Start(){
		foo = 0f;
		MaxDist = 2f;
		Manager = GameObject.Find ("Manager"); //finds 'Manager' storing list of game objects
		Managers = Manager.GetComponent<Manager> (); // gets script component storing said list
		Particles = Managers.GOs; // Copies list to this script
		timestep = Managers.timestep;
		meshRenderer = GetComponent<MeshRenderer>();
		meshRenderer.material.EnableKeyword("_EMISSION");
	}
	
	void Update () {
		if (timestep != 0f) {
			acceleration = Vector3.zero;
			foreach (GameObject GO in Particles) { //interaction for every particle to every other particle				
				if (GO != this.gameObject && foo < 1f) { // stops self-interaction
					Transform Trans = GO.GetComponent<Transform> ();
					Sphere sphere = GO.GetComponent<Sphere> ();
					float dist = Vector3.Magnitude (transform.position - Trans.position);
					float g = (-0.03f) / (dist * dist);


					if (state == State.gas || sphere.state == State.gas)
					{
						g += GasContact(sphere,g,dist,Trans);
					} else if (state == State.liquid || sphere.state == State.liquid) {
						g += LiquidContact(sphere,g,dist,Trans);
					} else {
						g += SolidContact(sphere,g,dist,Trans);
					}


					acceleration += Vector3.Normalize (transform.position - Trans.position) * g * (Managers.perfSave + 1f) ;

				}
				if (Managers.perfSave != 0f)
				{
					foo = (foo + 3.77347f) % (Managers.perfSave + 1f);
				}
			}
			velocity += acceleration * timestep; // iteration
		}
		if (Input.GetKey (KeyCode.Alpha1)) {
			velocity = Vector3.zero;
		}
		if (Input.GetKey (KeyCode.Alpha2)) {
			temperature = 300f;
		}
		if (Input.GetKeyDown (KeyCode.Slash)) {
			Object.Destroy (gameObject);
		}
	}

	float SolidContact(Sphere sp, float g, float dist, Transform Trans)
	{
		if (dist < 1.25f) {
			g += 0.2f / (dist * dist * dist * dist * dist) * (1.25f - dist); // 'pressure'
			//g -= 0.05f * dist * (2f - dist);
			float h = Vector3.Dot (velocity - sp.velocity, Vector3.Normalize (transform.position - Trans.position));
			if (h < 0f) {
				g += h * (-0.1f); // friction / damping
				temperature += (h * h) * (150f) * timestep;
			}
			float dt = sp.temperature - temperature;
			temperature += dt * Mathf.Clamp01(timestep * 0.0001f);
			sp.temperature -= dt * Mathf.Clamp01(timestep * 0.0001f);
		}
		return g;
	}

	float LiquidContact(Sphere sp, float g, float dist, Transform Trans)
	{
		if (dist < 1.25f) {
			g += 0.2f / (dist * dist * dist * dist * dist) * (1.25f - dist); // 'pressure'
			//g -= 0.05f * dist * (2f - dist);
			float h = Vector3.Dot (velocity - sp.velocity, Vector3.Normalize (transform.position - Trans.position));
			if (h < 0f) {
				g += h * (-0.07f); // friction / damping
				temperature += (h * h) * (110f) * timestep;
			}
			float dt = sp.temperature - temperature;
			temperature += dt * Mathf.Clamp01(timestep * 0.00015f);
			sp.temperature -= dt * Mathf.Clamp01(timestep * 0.00015f);
		}
		return g;
	}

	float GasContact(Sphere sp, float g, float dist, Transform Trans)
	{
		float pressurefactor = Mathf.Pow (temperature * 0.004f, 0.333f);
		if (dist < pressurefactor) {
			g += 0.2f / (dist * dist * dist) * (pressurefactor - dist); // 'pressure'
			//g -= 0.05f * dist * (2f - dist);
			float h = Vector3.Dot (velocity - sp.velocity, Vector3.Normalize (transform.position - Trans.position));
			if (h < 0.8f) {
				g += h * (-0.045f); // friction / damping
				temperature += Mathf.Clamp((h * Mathf.Abs(h)) * (-70f) * timestep,-temperature * 0.8f, Mathf.Infinity);
			}
			float dt = sp.temperature - temperature;
			temperature += dt * Mathf.Clamp01(timestep * 0.0001f);
			sp.temperature -= dt * Mathf.Clamp01(timestep * 0.0001f);
		}
		return g;
	}

	void LateUpdate()
	{
		if (timestep != 0f) {
			transform.position += velocity * timestep;
			if (!Physics.Raycast(transform.position,Dir,MaxDist))
			{
				temperature -= Mathf.Clamp(temperature * temperature * 0.00001f * timestep, -temperature * 0.7f, Mathf.Infinity);
			}
			Dir.x = Random.Range(-1f,1f);
			Dir.y = Random.Range(-1f,1f);
			Dir.z = Random.Range(-1f,1f);
			Dir.Normalize();
		}

		timestep = Managers.timestep;
		Particles = Managers.GOs;
		Color BBt = LerpC(Mathf.Clamp01(temperature / 300f - 2f),basecolor,BB (temperature));
		meshRenderer.material.color = BBt;
		if (temperature > 798) {
			BBt = LerpC (Mathf.Clamp01 (temperature / 300f - 2.3f), new Color (0f, 0f, 0f), BBt);
			meshRenderer.material.SetColor ("_EmissionColor", BBt);
		} else {
			meshRenderer.material.SetColor ("_EmissionColor", new Color(0f,0f,0f));
		}
		if (temperature < 1000) {
			state = State.solid;
		} else if (temperature < 2300) {
			state = State.liquid;
		} else {
			state = State.gas;
		}
	}
	
	
	Color BB(float temp)
	{
		bool above = temp > 2500 ? true : false;
		float foo = 1f / (((temp + 0.00001f) * 0.00015873015f) * ((temp + 0.00001f) * 0.00015873015f));
		float r, g, b;
		if (above) {
			r = 5511f / (Mathf.Pow (Mathf.Abs (1.3f + foo), 4.5f) + foo);
			//g = 3154f / (Mathf.Pow (Mathf.Abs (1f + foo), 4.5f) + foo);
			//b = 2000f / (Mathf.Pow (Mathf.Abs (0.8f + foo), 4.5f) + foo);
		} else if (Mathf.Sqrt(temp / 5500f) < 0.11f) {
			r = 0f;
		} else {
			r = Mathf.Sqrt(temp / 5500f) - 0.11f;
		}


		if (above) {
			g = 3154f / (Mathf.Pow (Mathf.Abs (1f + foo), 4.5f) + foo);
			//b = 2000f / (Mathf.Pow (Mathf.Abs (0.8f + foo), 4.5f) + foo);
		} else if (temp / 6000f < 0.10234215334f) {
			g = 0f;
		} else {
			g = Mathf.Pow(temp / 6000f,1.1f)*1.35f - 0.11f;
		}


		if (above) {
			b = 2000f / (Mathf.Pow (Mathf.Abs (0.8f + foo), 4.5f) + foo);
			} else if (temp / 6500f < 0.19740522994f) {
			b = 0f;
		} else {
			b = Mathf.Pow(temp / 6500f,1.9f)*2.4f - 0.11f;
		}

			r *= 1.01f;
			g *= 0.98f;

		float max = Mathf.Max (r, g, b) + 0.02f;
		r /= max;
		g /= max;
		b /= max;

		return new Color(r,g,b);
	}
	Color LerpC(float t, Color A, Color B)
	{
		float r = A.r * (1f - t) + B.r * t;
		float g = A.g * (1f - t) + B.g * t;
		float b = A.b * (1f - t) + B.b * t;

		return new Color(r,g,b);
	}
}
