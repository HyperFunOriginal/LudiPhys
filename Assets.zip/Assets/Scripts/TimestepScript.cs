﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TimestepScript : MonoBehaviour {

	GameObject GO;
	Text Txt;
	GameObject Manage;
	Manager Manager;
	// Use this for initialization
	void Start () {
		GO = gameObject;
		Manage = GameObject.Find ("Manager");
		Manager = Manage.GetComponent<Manager> ();
		Txt = GO.GetComponent<Text> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (Manager.timestep < 0.005f) {
			Txt.text = (Mathf.RoundToInt (Manager.timestep * 72000f).ToString ()) + " s/s";
		} else if (Manager.timestep < 0.05f) {
			Txt.text = (Mathf.RoundToInt (Manager.timestep * 1200f).ToString ()) + " min/s";
		} else if (Manager.timestep < 1.2f) {
			Txt.text = (Mathf.RoundToInt (Manager.timestep * 20f).ToString ()) + " hrs/s";
		} else {
			Txt.text = (Mathf.RoundToInt (Manager.timestep / 4.8f).ToString ()) + " days/s";
		}
	}
}
