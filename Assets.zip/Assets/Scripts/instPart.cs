﻿using UnityEngine;
using System.Collections;

public class instPart : MonoBehaviour {

	public Sphere sphere;
	public Transform transform;
	CamCom Cam;

	void Start()
	{
		Cam = gameObject.GetComponent<CamCom> ();
	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.Alpha0)) {
			Sphere Sp = (Sphere) Instantiate(sphere,transform.position,Quaternion.identity);
			Sp.velocity.x = Mathf.Cos(transform.eulerAngles.x * Mathf.Deg2Rad) * Mathf.Sin(transform.eulerAngles.y * Mathf.Deg2Rad) * 30f * Cam.speed;
			Sp.velocity.y = Mathf.Sin(transform.eulerAngles.x * Mathf.Deg2Rad) * (-30f) * Cam.speed;
			Sp.velocity.z = Mathf.Cos(transform.eulerAngles.x * Mathf.Deg2Rad) * Mathf.Cos(transform.eulerAngles.y * Mathf.Deg2Rad) * 30f * Cam.speed;
		}
		if (Input.GetKeyDown(KeyCode.Return)) {
			Sphere Sp = (Sphere) Instantiate(sphere,transform.position,Quaternion.identity);
			Sp.velocity = Vector3.zero;
			Sp.transform.position = new Vector3(Random.Range(-1f,1f),Random.Range(-1f,1f),Random.Range(-1f,1f)) + gameObject.transform.position;
		}
	}
}
