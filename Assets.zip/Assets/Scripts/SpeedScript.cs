﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SpeedScript : MonoBehaviour {

	GameObject GO;
	Text Txt;
	GameObject Cam;
	CamCom CamCam;
	// Use this for initialization
	void Start () {
		GO = gameObject;
		Cam = GameObject.Find ("CamPos");
		CamCam = Cam.GetComponent<CamCom> ();
		Txt = GO.GetComponent<Text> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (CamCam.speed < 0.01f) {
			Txt.text = (Mathf.RoundToInt (CamCam.speed * 1000000f).ToString ()) + " m/rs";
		} else if (CamCam.speed < 1f) {
			Txt.text = (Mathf.RoundToInt (CamCam.speed * 1000f).ToString ()) + " km/rs";
		} else {
			Txt.text = (Mathf.RoundToInt (CamCam.speed).ToString ()) + " Mm/rs";
		}
	}
}
